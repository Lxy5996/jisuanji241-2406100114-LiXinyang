package com.example.personalaccount;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView lvRecords;
    private ArrayList<String> recordList;
    private ArrayAdapter<String> adapter;

    private final ActivityResultLauncher<Intent> addLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    String record = result.getData().getStringExtra("record");
                    if (record != null) {
                        recordList.add(0, record);
                        adapter.notifyDataSetChanged();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        lvRecords = findViewById(R.id.lvRecords);
        Button btnAdd = findViewById(R.id.btnAdd);

        String username = getIntent().getStringExtra("username");
        if (username == null) username = "用户";
        tvWelcome.setText("欢迎，" + username + "！");

        recordList = new ArrayList<>();
        recordList.add("支出｜餐饮｜¥35.00｜非固定｜午餐");
        recordList.add("收入｜工资｜¥8000.00｜非固定｜月薪");
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, recordList);
        lvRecords.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddRecordActivity.class);
            addLauncher.launch(intent);
        });
    }
}