package com.example.personalaccount;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddRecordActivity extends AppCompatActivity {
    private EditText etAmount, etRemark;
    private RadioGroup rgType;
    private Spinner spCategory;
    private CheckBox cbFixed;
    private final String[] categories = {"餐饮", "交通", "购物", "工资", "其他"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);

        etAmount = findViewById(R.id.etAmount);
        etRemark = findViewById(R.id.etRemark);
        rgType = findViewById(R.id.rgType);
        spCategory = findViewById(R.id.spCategory);
        cbFixed = findViewById(R.id.cbFixed);
        Button btnSave = findViewById(R.id.btnSave);

        ArrayAdapter<String> spAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, categories);
        spAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(spAdapter);

        btnSave.setOnClickListener(v -> saveRecord());
    }

    private void saveRecord() {
        String amountStr = etAmount.getText().toString().trim();
        if (TextUtils.isEmpty(amountStr)) {
            Toast.makeText(this, "请输入金额", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "金额格式不正确", Toast.LENGTH_SHORT).show();
            return;
        }
        if (amount <= 0) {
            Toast.makeText(this, "金额必须大于 0", Toast.LENGTH_SHORT).show();
            return;
        }

        String type = (rgType.getCheckedRadioButtonId() == R.id.rbIncome) ? "收入" : "支出";
        String category = spCategory.getSelectedItem().toString();
        String fixed = cbFixed.isChecked() ? "固定" : "非固定";
        String remark = etRemark.getText().toString().trim();
        if (TextUtils.isEmpty(remark)) remark = "无";

        String record = String.format("%s｜%s｜¥%.2f｜%s｜%s", type, category, amount, fixed, remark);

        Intent resultIntent = new Intent();
        resultIntent.putExtra("record", record);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}